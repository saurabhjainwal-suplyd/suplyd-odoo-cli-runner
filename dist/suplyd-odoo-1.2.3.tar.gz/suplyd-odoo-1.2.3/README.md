# suplyd-odoo-cli-runner

### Steps

1. Install `sup-odoo` cli tool by running this command `pip install suplyd-odoo`/`python3 -m pip install sup-odoo`/`python -m pip install sup-odoo`
2. To start the Odoo instance run this command `sup-odoo start`/`python3 -m sup-odoo start`/`python -m sup-odoo start`
3. To stop the Odoo instance run this command `sup-odoo stop`/`python3 -m sup-odoo stop`/`python -m sup-odoo stop`
4. To see help `sup-odoo --help`/`python3 -m sup-odoo --help`/`python -m sup-odoo --help`
